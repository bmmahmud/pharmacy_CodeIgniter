
 <!-- /.container -->
 <section id="main">
	 <div class="container">
<div class="row">
   <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading main-color-bg">
        <h3 class="panel-title">Inventory Overview</h3>
      </div>
      <div class="panel-body">
       <div class="col-md-3">
         <div class="well dash-box">
           <h2> <span class="glyphicon glyphicon-th" aria-hidden="true"></span>10</h2>
          <h4>Medicine Qty</h4>
          </div>
      </div>
      <div class="col-md-3">
          <div class="well dash-box">
            <h2> <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>10</h2>
           <h4>Product Qty</h4>
           </div>
       </div>
       <div class="col-md-3">
          <div class="well dash-box">
            <h2> <span class="glyphicon glyphicon-btc" aria-hidden="true"></span>12</h2>
           <h4>Sales</h4>
           </div>
       </div>
       <div class="col-md-3">
          <div class="well dash-box">
            <h2> <span class="glyphicon glyphicon-equalizer" aria-hidden="true"></span>15</h2>
           <h4>Stock</h4>
           </div>
       </div>
    </div>
   </div>

		   </div >
			   </div >
 </section>
