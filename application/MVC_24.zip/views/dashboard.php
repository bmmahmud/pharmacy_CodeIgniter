
 <!-- /.container -->
 <section id="main">
	 <div class="container">
<div class="row">
   <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading main-color-bg">
        <h3 class="panel-title">Inventory Overview</h3>
      </div>
      <div class="panel-body">
       <div class="col-md-4">
         <div class="well dash-box">
           <h2> <span class="glyphicon glyphicon-th" aria-hidden="true" style="color: #4cae4c;"></span> 10</h2>
          <h4>Medicine Qty</h4>
          </div>
      </div>
      <div class="col-md-4">
          <div class="well dash-box">
            <h2> <span class="glyphicon glyphicon-th-large" aria-hidden="true" style="color: palevioletred;"></span> 10</h2>
           <h4>Purchase List</h4>
           </div>
       </div>
       <div class="col-md-4">
          <div class="well dash-box">
            <h2> <span class="glyphicon glyphicon-usd" aria-hidden="true" style="color: red;"></span> 12</h2>
           <h4>Sales</h4>
           </div>
       </div>
       <div class="col-md-4">
          <div class="well dash-box">
            <h2> <span class="	glyphicon glyphicon-user" aria-hidden="true" style="color: #2e6da4;"></span> 15</h2>
           <h4> Customer</h4>
           </div>
       </div>
		  <div class="col-md-4">
			  <div class="well dash-box">
				  <h2> <span class="glyphicon glyphicon-fire" aria-hidden="true" style="color: orange;"></span> 15</h2>
				  <h4> Today's Sale</h4>
			  </div>
		  </div>
		  <div class="col-md-4">
			  <div class="well dash-box">
				  <h2> <span class="glyphicon glyphicon-warning-sign" aria-hidden="true" style="color: darkred;"></span> 15</h2>
				  <h4>  Expire Product</h4>
			  </div>
		  </div>
    </div>
   </div>

	</div >
  </div >
 </section>



